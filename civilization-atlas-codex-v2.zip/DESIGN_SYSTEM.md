# Civilization Atlas — Design System V2

> Scope: current Civilization Atlas site  
> URL reviewed: https://civilization-atlas-cn.dadahere0905.chatgpt.site/  
> Primary direction: **Apple Editorial × Digital Museum × Academic Atlas**  
> Secondary direction: restrained data visualization  
> Avoid: SaaS dashboard, generic AI landing page, over-carded UI, excessive glassmorphism

---

## 0. What must stay unchanged

Codex must preserve:
- All factual copy and historical content unless explicitly instructed otherwise.
- Existing section order:
  1. 比较模型
  2. 时间长轴
  3. 文明互鉴
  4. 阅读结论
  5. 继续阅读
- Existing civilization comparison logic.
- Existing timeline interaction.
- Existing culture-to-culture comparison logic.
- Existing “MODEL NOTES / V1.0” and “HOW TO READ” informational layers.
- Existing print/export function unless a technical change is necessary.
- Existing semantic headings where practical.
- Keyboard accessibility and visible focus states.
- Mobile usability.

The redesign is a visual hierarchy and layout refactor, not a content rewrite.

---

# 1. Design Thesis

This site should feel like:

> A serious digital atlas of civilizations with the restraint of Apple editorial pages and the authority of a museum exhibition catalogue.

The page should **not** feel like:
- analytics software;
- a startup dashboard;
- a Notion template;
- a card collection;
- a typical AI-generated marketing page;
- an educational PPT converted to HTML.

The user should experience:
1. strong opening statement;
2. generous spatial pauses;
3. one dominant idea per viewport;
4. precise typography;
5. editorial asymmetry;
6. subtle, intentional interaction;
7. quiet data visualization;
8. cultural color used as notation, not decoration.

---

# 2. Current Information Architecture

Current page content has these primary layers:

## Header
- 六 / 文明构型
- CIVILIZATION ATLAS · 01
- 比较模型
- 时间长轴
- 文明互鉴
- 模型说明 ↗

## Hero
- 比较文化研究工具
- 约 3100 BCE — 当代
- 六条文化河流
- 一张理解世界的图谱
- explanatory lead
- 进入模型 ↓
- 导出阅读版 ⌘P
- relation diagram hint
- four summary metrics:
  - 06 文化系统
  - 08 观察维度
  - 05K+ 年历史跨度
  - ∞ 内部多样性

## 01 比较模型
- culture tabs / selectors
- culture identity block
- culture proposition
- radar / construct comparison
- pair comparison
- 八维阅读器
- “同一个维度，六种回答”

## 02 时间长轴
- explanatory intro
- range filters
- timeline
- methodological note

## 03 文明互鉴
- relation path
- route navigation
- text fields:
  - 媒介
  - 观察窗口
  - 研究提醒

## 04 阅读结论
- three editorial conclusions

## 05 继续阅读
- six traditions
- canonical reading entry points
- closing statement

## Informational overlays
- MODEL NOTES / V1.0
- HOW TO READ

The redesign must make these layers visibly distinct.

---

# 3. Global Layout

## 3.1 Page widths

```css
--page-max: 1600px;
--content-max: 1200px;
--editorial-max: 960px;
--reading-max: 720px;
--reading-narrow: 620px;
```

Use:
- 1600px only for visual systems that genuinely benefit from width.
- 1200px for standard desktop sections.
- 960px for editorial compositions.
- 720px for long explanatory copy.

### Rule
Do **not** let long paragraphs span the full content width.

---

## 3.2 Page gutters

```css
--gutter-desktop-xl: 64px;
--gutter-desktop: 48px;
--gutter-tablet: 32px;
--gutter-mobile: 20px;
```

Recommended:

```css
.site-shell {
  width: min(
    calc(100% - (2 * var(--gutter-desktop))),
    var(--content-max)
  );
  margin-inline: auto;
}
```

At ≥ 1600px, 64px gutters are acceptable.

---

# 4. Grid

Desktop:
- 12-column grid
- 24px column gap

Tablet:
- 8-column grid
- 20px gap

Mobile:
- 4-column grid
- 16px gap

```css
.editorial-grid {
  display: grid;
  grid-template-columns: repeat(12, minmax(0, 1fr));
  gap: 24px;
}
```

Use asymmetry deliberately:
- section number: columns 1–2
- main heading: columns 3–9
- note/caption: columns 10–12

Do not center everything.

---

# 5. Typography

## 5.1 Font stack

Use system fonts.

```css
font-family:
  -apple-system,
  BlinkMacSystemFont,
  "SF Pro Display",
  "SF Pro Text",
  "PingFang SC",
  "Helvetica Neue",
  Arial,
  sans-serif;
```

Do not bundle or redistribute Apple font files.

Chinese must remain optimized for PingFang SC.

---

## 5.2 Type scale

Use a small number of deliberate tiers.

| Token | Desktop | Mobile | Weight | Line Height | Tracking |
|---|---:|---:|---:|---:|---:|
| display-xxl | clamp(72px, 7vw, 108px) | 48–56px | 600 | .94–.98 | -0.045em |
| display-xl | clamp(56px, 5vw, 76px) | 40–46px | 600 | 1.00 | -0.035em |
| h1 | 56px | 38px | 600 | 1.04 | -0.03em |
| h2 | 44–48px | 32–36px | 600 | 1.08 | -0.025em |
| h3 | 30–32px | 26–28px | 600 | 1.15 | -0.018em |
| lead | 21–24px | 19–21px | 400 | 1.48 | -0.01em |
| body-lg | 19px | 18px | 400 | 1.65 | 0 |
| body | 17px | 17px | 400 | 1.68 | 0 |
| label | 14px | 13px | 500 | 1.35 | .02em |
| caption | 12–13px | 12px | 500 | 1.4 | .025em |

Chinese tracking:
- avoid excessive negative tracking;
- use visual correction per heading;
- never compress long Chinese body text.

---

## 5.3 Hero title

Current:
- 六条文化河流
- 一张理解世界的图谱

Recommended visual treatment:

```css
.hero-title {
  font-size: clamp(54px, 7.4vw, 108px);
  line-height: .95;
  font-weight: 600;
  letter-spacing: -0.042em;
  max-width: 9.2em;
}
```

Desktop:
- left aligned;
- two deliberate lines;
- avoid a centered marketing-page composition.

The secondary title can be visually lighter:
- either same size but tertiary color;
- or 74–85% of line one.

Do not turn it into a gradient heading.

---

# 6. Vertical Rhythm

Use large spacing between conceptual chapters.

```css
--section-space-desktop: 200px;
--section-space-tablet: 144px;
--section-space-mobile: 104px;
```

Major chapter:

```css
.section-major {
  padding-block: clamp(104px, 12vw, 220px);
}
```

Within a section:
- eyebrow → title: 24–40px
- title → lead: 28–40px
- lead → core interactive module: 64–96px
- module → methodological note: 40–64px

Avoid stacking unrelated modules at 24–40px intervals.

---

# 7. Spacing Tokens

Use this scale:

```css
--space-1: 4px;
--space-2: 8px;
--space-3: 12px;
--space-4: 16px;
--space-5: 24px;
--space-6: 32px;
--space-7: 40px;
--space-8: 48px;
--space-9: 64px;
--space-10: 80px;
--space-11: 96px;
--space-12: 120px;
--space-13: 144px;
--space-14: 160px;
--space-15: 200px;
--space-16: 240px;
```

Do not scatter arbitrary spacing values throughout components.

---

# 8. Color System

## Neutral palette

```css
--color-bg: #F5F5F3;
--color-surface: #FFFFFF;
--color-surface-muted: #ECECE8;

--color-text: #1D1D1F;
--color-text-secondary: #6E6E73;
--color-text-tertiary: #86868B;
--color-text-inverse: #F5F5F7;

--color-line: rgba(29,29,31,.12);
--color-line-strong: rgba(29,29,31,.20);
```

Do not use pure black for all text.
Do not use excessive gray-on-gray that harms contrast.

---

## Civilization accents

Use accents as cartographic notation.

Suggested muted palette:

```css
--egypt: #A67C3B;
--greece: #466C8A;
--judaism: #435B8C;
--christianity: #7A4E5A;
--islam: #47725D;
--buddhism: #B47B35;
```

Accent allocation:
- ideally 5–10% of visible screen area;
- never a full-page background purely to identify a civilization;
- use in nodes, fine rules, active states, chart traces, tiny labels.

---

# 9. Surfaces and Cards

## Core rule

If a section can work without a card, do not make it a card.

Avoid:
- nested cards;
- 20+ rounded boxes on one viewport;
- every paragraph inside a surface;
- floating SaaS panels;
- heavy shadow;
- glass blur as default.

Recommended:

```css
--radius-sm: 10px;
--radius-md: 16px;
--radius-lg: 24px;
--radius-xl: 32px;
--radius-pill: 999px;
```

Use:
- 0–12px for data/timeline containers;
- 16px for ordinary interactive surfaces;
- 24–32px only for major visual fields.

Shadows:
```css
box-shadow: none;
```

If elevation is required:
```css
box-shadow: 0 1px 0 rgba(0,0,0,.04);
```

Prefer border and spacing to shadow.

---

# 10. Header

Current header has enough conceptual material; make it visually quieter.

Desktop target:
- height: 56–64px
- sticky optional
- translucent effect only if technically clean
- thin bottom divider only after scrolling, if needed

Suggested layout:
- left: 六 / 文明构型
- center/right: section anchors
- far right: 模型说明 ↗

Typography:
```css
font-size: 13px;
font-weight: 500;
letter-spacing: .01em;
```

Avoid oversized navigation pills.

Mobile:
- preserve identity;
- collapse section navigation cleanly;
- do not squeeze five anchors into one line.

---

# 11. Hero — Specific Redesign

The hero should be the strongest editorial composition.

Recommended composition:

```text
比较文化研究工具                     约 3100 BCE — 当代


六条文化河流，
一张理解世界的图谱。


                    把埃及、希腊、犹太教、基督教、
                    伊斯兰教与佛教文化放进同一套坐标……

进入模型 ↓
导出阅读版 ⌘P


────────────────────────────────────────────

06                  08                  05K+                ∞
文化系统             观察维度             年历史跨度          内部多样性
```

Rules:
- left aligned;
- hero height approx 82–95svh on desktop;
- do not vertically center all elements;
- title begins around upper 25–32% of viewport;
- lead should occupy a separate column on wide screens;
- metrics should feel like a quiet footer to the hero.

The “关系示意 / 非谱系图 / 点击节点进入比较” instruction should look like a curatorial annotation, not a tooltip.

---

# 12. Section Heading Pattern

Standard chapter heading:

```text
01
比较模型


选择主文化，
再找一面镜子。


                                  图中数值表示……
                                  不代表发展水平……
```

Use editorial grid.

Section number:
```css
font-size: 12–13px;
font-weight: 600;
letter-spacing: .08em;
```

Title:
```css
font-size: clamp(38px, 4vw, 60px);
line-height: 1.04;
```

Avoid:
`01 / 比较模型` as one visually undifferentiated string.

It may remain in DOM/accessibility text but render with clear hierarchy.

---

# 13. 01 / 比较模型

This is the most information-dense section.

## 13.1 Culture selector

Do not render six civilizations as six generic SaaS pills.

Prefer:
- horizontal editorial index;
- thin active underline;
- numeral + civilization name;
- active culture color only as subtle accent.

Example:

```text
01 埃及     02 希腊     03 犹太教     04 基督教     05 伊斯兰教     06 佛教
────────
```

Mobile:
- horizontally scrollable with snap;
- 44px minimum touch target;
- no hidden active state.

---

## 13.2 Culture identity block

Current content:
- date/location
- large character such as “埃”
- ANCIENT EGYPT
- 埃及文化
- proposition

Make it a major editorial plate.

Recommended:
- large ideographic marker: 120–220px desktop;
- English label small, spaced;
- Chinese culture name: 36–48px;
- proposition: 24–32px serif is optional only if already supported by the project; otherwise keep system sans.

Do not use decorative historical fonts.

---

## 13.3 Radar / construct visualization

The radar must feel analytical, not gamified.

Rules:
- thin grid lines;
- muted neutral grid;
- one or two accent strokes;
- no bright filled radar polygons at high opacity;
- labels remain legible;
- comparison mode uses two differentiated line styles / colors;
- explanatory note remains near the visualization.

Avoid giant legends.

---

## 13.4 “八维阅读器”

Treat this as a reading framework, not a dashboard.

Prefer:
- one dimension at a time;
- generous vertical space;
- side-by-side cultural response on desktop;
- stacked response on mobile;
- thin separators.

If all eight dimensions are shown, use an editorial list rather than card tiles.

---

## 13.5 “同一个维度，六种回答”

This should be a visual pause and comparison statement.

Prefer:
- one chosen dimension;
- six textual responses;
- consistent alignment;
- restrained accent coding.

No six equal rounded cards unless required by the existing interaction.

---

# 14. 02 / 时间长轴

This should be one of the visual peaks of the entire website.

## Desktop

```css
.timeline-section {
  min-height: 85svh;
}
```

Use width:
```css
max-width: 1440px;
```

The timeline should not feel trapped in a small card.

Layout:
- chapter label top;
- heading and lead;
- filter controls;
- large timeline field;
- methodological note below.

Timeline:
- horizontal;
- strong baseline;
- subtle ticks;
- labels with collision avoidance;
- culture rows visually calm;
- arrow for traditions extending to the present.

Range controls:
- compact segmented control or textual tabs;
- do not over-style.

Methodological note:
- 13–15px;
- max-width: 720px;
- tertiary text.

---

# 15. 03 / 文明互鉴

Current route concept is excellent for an editorial story.

Transform it into:

```text
03
文明互鉴

文化之间，
没有真空.



埃及文化                                      希腊文化
EGYPT                                         GREECE

                         →

               从尼罗河到亚历山大里亚


媒介                观察窗口                研究提醒
...
```

Rules:
- the path title becomes dominant;
- the arrow/path is visual;
- “媒介 / 观察窗口 / 研究提醒” are editorial columns, not dashboard stats;
- route counter `01 / 07` stays quiet;
- previous/next controls may be icon/text buttons;
- maintain 44px clickable target on touch devices.

---

# 16. 04 / 阅读结论

Current:
1. 同词不必同义
2. 传统内部始终多元
3. 交流常伴随张力

Do not make these three equal cards.

Use a vertical manifesto:

```text
Ⅰ
同词，
不必同义。

explanation...


────────────────────────────────


Ⅱ
传统内部，
始终多元。

explanation...
```

Heading:
- 44–64px desktop
- 32–40px mobile

Explanation:
- max-width 620–720px
- 17–19px

Each conclusion should have enough space to become a chapter-like beat.

---

# 17. 05 / 继续阅读

This section should feel like a bibliography/catalogue.

Recommended desktop:
- 2-column or 3-column editorial catalogue;
- no large card chrome;
- thin rules;
- civilization name as category;
- primary texts as title;
- one-line explanation.

Example:

```text
埃及
金字塔文 · 亡灵书
王权、死后生命与玛阿特秩序
────────────────────
```

Mobile:
- single column;
- generous 28–36px item spacing.

---

# 18. Footer

Current closing statement is strong:

> 一个用于提问的比较框架，不是将复杂传统压缩为标签的答案。

Give it more authority.

Desktop:
- 42–64px
- max-width 900px
- 120–180px top and bottom breathing room

The split characters “文 / 明” can remain as a graphic device only if they do not reduce readability.

Footer metadata:
- small;
- quiet;
- aligned to grid.

---

# 19. MODEL NOTES / HOW TO READ

Use a proper editorial modal/drawer.

Desktop:
- width: min(720px, 50vw)
- generous padding 48–64px
- no heavy shadow
- readable body copy
- fixed close control
- focus trap
- Escape closes
- background scroll lock

Mobile:
- full-screen or nearly full-screen sheet
- 20–24px side padding
- safe-area aware
- close control minimum 44×44px

Do not use tiny modal text.

---

# 20. Interaction & Motion

Motion must feel restrained.

Use:
```css
--ease-editorial: cubic-bezier(.2,.75,.25,1);
--duration-fast: 180ms;
--duration-base: 320ms;
--duration-slow: 600ms;
```

Allowed:
- opacity;
- translateY 8–20px;
- line reveal;
- graph path transition;
- subtle section intro.

Avoid:
- excessive parallax;
- springy dashboard animation;
- glowing hover;
- 3D tilt cards;
- constant floating objects;
- cursor gimmicks.

Respect:
```css
@media (prefers-reduced-motion: reduce)
```

---

# 21. Accessibility

Mandatory:
- semantic heading hierarchy;
- visible keyboard focus;
- 44×44px touch targets where possible;
- contrast-safe text;
- no information encoded only by color;
- radar/timeline include accessible textual equivalents;
- modals use aria attributes appropriately;
- horizontal mobile scrollers remain keyboard accessible;
- body text minimum 16px;
- no layout break at 200% zoom;
- support reduced motion.

---

# 22. Responsive Breakpoints

```css
--bp-mobile: 767px;
--bp-tablet: 1023px;
--bp-desktop: 1279px;
--bp-wide: 1599px;
```

### ≥1600
- max content 1200–1440
- hero 96–108px
- major section gap 200–240px
- 12-column grid

### 1280–1599
- hero 80–96px
- gutters 48px
- section gap 180–220px

### 1024–1279
- hero 68–80px
- 8–12 column adaptive grid
- section gap 144–180px

### 768–1023
- hero 56–68px
- gutters 32px
- reduce multi-column layouts

### ≤767
- hero 48–56px
- gutters 20px
- body 17px
- section gap 96–120px
- most editorial grids stack
- timeline may use horizontal scroll if necessary
- culture selector horizontally scrolls

---

# 23. Visual QA Checklist

The redesign passes only if:

- [ ] First viewport has one dominant typographic statement.
- [ ] Hero is not a centered generic landing page.
- [ ] Long copy width is ≤720px.
- [ ] Major sections have ≥144px desktop conceptual separation.
- [ ] There are fewer rounded cards than the current typical SaaS pattern.
- [ ] Shadows are nearly absent.
- [ ] Culture colors are accents, not backgrounds.
- [ ] Timeline is visually important.
- [ ] “文明互鉴” reads like a story, not a panel.
- [ ] “阅读结论” reads like a manifesto, not three cards.
- [ ] “继续阅读” reads like a catalogue.
- [ ] Mobile typography remains large and deliberate.
- [ ] No horizontal page overflow.
- [ ] Existing logic and content remain intact.
- [ ] Focus styles are visible.
- [ ] Reduced-motion mode works.

---

# 24. Source Principles

This design system is inspired by current Apple design principles, not a claim that the exact CSS values are copied from apple.com.

Reference principles:
- purpose, consistency, familiarity, flexibility, simplicity, craft and delight;
- typography should create hierarchy and remain legible;
- avoid too many typefaces;
- layouts should adapt gracefully to context;
- spacing between controls matters for usability;
- system fonts should be used appropriately rather than redistributed.

Implementation values in this file are project-specific recommendations for Civilization Atlas.
