# CODEX TASK — Civilization Atlas V2 Visual Refactor

## Objective

Refactor the current Civilization Atlas website to comply with `DESIGN_SYSTEM.md` and `civilization-design-system.css`.

This is a **visual hierarchy, typography, spacing and composition refactor**.

Do not rewrite historical content.
Do not simplify the research model.
Do not remove interactions.

---

# Required workflow

## Step 1 — Inspect before editing

Read:
1. `DESIGN_SYSTEM.md`
2. `civilization-design-system.css`
3. the current app structure
4. global stylesheet(s)
5. section components
6. timeline implementation
7. comparison/radar implementation
8. modals/drawers
9. responsive styles

Identify:
- framework;
- global CSS architecture;
- component boundaries;
- duplicate spacing/type values;
- places where generic cards are overused;
- mobile overflow risks.

Do not replace the whole application blindly.

---

# Step 2 — Create design tokens

Integrate the token layer from:

`civilization-design-system.css`

Prefer:
- CSS variables;
- shared utility classes;
- reusable section primitives.

Do not scatter new one-off pixel values throughout JSX/TSX/HTML.

---

# Step 3 — Refactor global page shell

Implement:
- max content width;
- responsive gutters;
- reading-width constraints;
- editorial grids;
- section spacing;
- typography tokens.

Expected:
- desktop feels spacious;
- mobile remains dense enough to use;
- no accidental ultra-wide paragraphs.

---

# Step 4 — Header

Refactor header into a quieter editorial navigation.

Preserve:
- brand/title;
- 比较模型;
- 时间长轴;
- 文明互鉴;
- 模型说明.

Requirements:
- 56–64px desktop height;
- compact type;
- no large pill navigation;
- mobile navigation must not squeeze all labels into one row;
- preserve anchor behavior.

---

# Step 5 — Hero

Hero is the highest-priority visual change.

Use:
- left-aligned composition;
- 82–95svh desktop target;
- very large title;
- separate lead column on large screens;
- quieter metadata;
- metrics aligned like an atlas index.

Do not:
- use a gradient headline;
- center everything;
- add decorative blobs;
- add hero cards;
- use large shadows.

Preserve exact copy.

---

# Step 6 — Section heading primitive

Build or refactor a reusable section-heading pattern.

It should support:
- section number;
- section name;
- large title;
- optional explanatory note.

Use editorial grid asymmetry.

Apply to:
- 01 比较模型
- 02 时间长轴
- 03 文明互鉴
- 04 阅读结论
- 05 继续阅读

---

# Step 7 — Comparison model

Preserve all comparison behavior.

Refactor visual presentation:
- culture selector becomes an editorial index, not generic pills;
- active state uses a subtle rule/accent;
- culture identity block becomes more spacious;
- radar styling becomes quieter;
- comparison reader uses separators and type hierarchy rather than nested cards;
- reduce card count where semantics do not require containment.

Mobile:
- horizontal selector may scroll;
- ensure active civilization remains visible;
- no clipped labels.

---

# Step 8 — Timeline

Make timeline a major visual chapter.

Requirements:
- timeline field can use up to 1440px width;
- not trapped in a small rounded card;
- filter controls remain compact;
- labels must not collide;
- methodological note remains readable;
- present-day continuation arrows remain clear;
- mobile can use controlled horizontal scroll if needed.

Do not reduce timeline into a decorative miniature.

---

# Step 9 — Civilization exchange

Refactor the current route module into an editorial narrative composition.

Make:
- origin civilization;
- destination civilization;
- visual direction;
- route title;
- 媒介;
- 观察窗口;
- 研究提醒

read as one story.

Preserve:
- 01 / 07 counter;
- previous/next controls;
- route switching.

Avoid:
- three generic metric cards;
- dashboard stat styling.

---

# Step 10 — Reading conclusions

Replace equal-card composition with a vertical editorial manifesto.

Each conclusion:
- Roman numeral;
- large title;
- explanatory paragraph;
- divider or whitespace.

Do not place all three inside identical rounded boxes.

---

# Step 11 — Further reading

Turn into a restrained bibliography/catalogue.

Use:
- 2–3 columns desktop depending on available width;
- 1 column mobile;
- thin rules;
- no heavy card chrome.

Preserve all six traditions and text recommendations.

---

# Step 12 — MODEL NOTES and HOW TO READ

Refactor as accessible editorial modal/drawer.

Requirements:
- focus trap;
- Escape closes;
- visible close button;
- background scroll lock;
- mobile safe-area support;
- readable line length;
- no tiny text.

---

# Step 13 — Motion

Use restrained motion only.

Implement:
- short hover transitions;
- section entrance where already appropriate;
- chart transitions;
- route transition.

Respect:
`prefers-reduced-motion`.

Do not add:
- 3D card tilt;
- cursor effects;
- excessive parallax;
- glow animation;
- bouncing UI.

---

# Step 14 — Responsive QA

Test at minimum:
- 375 × 812
- 390 × 844
- 768 × 1024
- 1024 × 768
- 1280 × 800
- 1440 × 900
- 1728 × 1117

Check:
- no horizontal page overflow;
- no clipped hero;
- no tiny controls;
- no collision in timeline;
- modals usable;
- culture selector usable;
- paragraph widths appropriate;
- title wraps intentionally.

---

# Step 15 — Accessibility QA

Verify:
- keyboard navigation;
- focus-visible styles;
- semantic headings;
- color contrast;
- no color-only communication;
- 44px touch targets where practical;
- reduced motion;
- zoom to 200%;
- modal semantics.

---

# Technical constraints

## Do not
- change factual copy;
- delete features to simplify styling;
- introduce a heavy UI component framework only for this refactor;
- add dependencies unless necessary;
- bundle Apple proprietary font files;
- rewrite stable working logic without reason;
- overuse CSS `!important`;
- create dozens of inline styles;
- create visual effects unrelated to the design system.

## Prefer
- existing framework conventions;
- CSS variables;
- semantic HTML;
- shared layout primitives;
- component-level CSS modules or the project's current styling method;
- minimal dependency changes.

---

# Completion criteria

The work is complete only when:

1. Site visually matches the editorial direction in `DESIGN_SYSTEM.md`.
2. Existing interactions still work.
3. Desktop composition is substantially more spacious and typographically confident.
4. Mobile is fully usable.
5. No obvious SaaS/dashboard styling remains in major sections.
6. Timeline and exchange path become visual focal points.
7. Browser console has no new errors.
8. Production build succeeds.
9. Lint/typecheck passes if configured.
10. A concise summary of changed files and visual decisions is provided.

---

# Final Codex instruction

Do not merely restyle colors.

Treat this as a system-level editorial layout refactor.

Prioritize in this exact order:

1. typography hierarchy
2. negative space
3. content width
4. section composition
5. comparison/timeline visualization
6. interaction polish
7. decorative detail

When a design decision is ambiguous, choose the simpler and more editorial option.
