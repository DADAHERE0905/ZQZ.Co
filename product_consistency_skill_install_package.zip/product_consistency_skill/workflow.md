# Product Consistency Workflow

## Full Workflow

Reference Lock
↓
White Background Product Test
↓
Multi-angle Consistency Test
↓
Simple Scene Test
↓
Final Shot Generation
↓
Shot-by-shot Reference Comparison
↓
Logo / Text / UI Post Fix
↓
Final Color and Material Match

## 中文流程

参考图锁定
↓
产品白底测试
↓
多角度一致性测试
↓
简单场景测试
↓
正式分镜生成
↓
逐镜对比参考图
↓
Logo / 文字 / UI 后期修正
↓
统一调色与材质

## Minimum Workflow

参考锁定 → 白底测试 → 场景测试 → 正式生成 → 对比审核 → 后期修正
