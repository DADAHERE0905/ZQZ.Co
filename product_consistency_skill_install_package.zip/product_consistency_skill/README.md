# Product Consistency Skill 安装说明

## 用途
这是一个用于 AIGC 图片 / 分镜 / 视频生产的产品一致性控制 Skill。

适合：
- 广告分镜图
- 产品TVC
- AIGC商业视觉
- 汽车 / 电动车 / 手机 / 啤酒 / 耳机 / 包装产品
- 需要同一产品跨镜头保持一致的项目

## 安装方式

### 方式 1：作为通用 Skill 使用
把整个文件夹复制到你的 Skill / Prompt / Workflow 管理目录中。

推荐目录名：

```text
product_consistency_skill
```

### 方式 2：在 Codex / 本地工作流中使用
将 `SKILL.md` 放入对应项目的 skills 目录。

例如：

```text
/your-project/skills/product_consistency_skill/SKILL.md
```

### 方式 3：团队协作
把 `templates/` 和 `review_checklist.md` 发给制作人员。
每个镜头必须使用 `master_prompt.txt`，每轮审核必须使用 `review_checklist.md`。

## 最小执行方式

1. 先准备产品参考图
2. 用 `master_prompt.txt`
3. 先做白底测试
4. 再做场景测试
5. 每轮只修一个问题
6. 用 `review_checklist.md` 做通过 / 淘汰判断

## 核心原则

```text
AI负责气质。
资产负责准确。
```
