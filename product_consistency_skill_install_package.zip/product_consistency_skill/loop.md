# Product Consistency Loop

## Loop

Generate
↓
Compare with reference
↓
Find one main error
↓
Fix only that error
↓
Regenerate
↓
Approve or reject

## Rule

Do not fix many problems in one round.
Each loop fixes only one main product problem.

## Correction Prompts

```text
Only fix the product [problem].
Keep everything else unchanged.
```

```text
Only fix the product proportions.
Keep everything else unchanged.
```

```text
Only fix the logo position.
Keep everything else unchanged.
```

```text
Only fix the material texture.
Keep everything else unchanged.
```

```text
Only fix the product silhouette.
Keep everything else unchanged.
```

```text
Only fix the structural details of the product.
Keep everything else unchanged.
```
