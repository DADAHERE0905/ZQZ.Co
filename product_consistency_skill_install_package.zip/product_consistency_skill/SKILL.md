# Skill: Product Consistency Control

## Purpose
Keep the same product visually consistent across AIGC images, storyboards, and video shots.

The product must keep:
- same silhouette
- same proportions
- same color
- same material
- same texture
- same logo position
- same structural details

Core principle:

> AI creates atmosphere. Assets protect accuracy.

---

## Required Inputs
Before generating, prepare:

1. Product reference images:
   - front view
   - side view
   - rear view
   - 45-degree view
   - detail close-ups

2. Logo source file

3. Standard color reference

4. Key product structure notes

5. Forbidden changes list

Without these inputs, product consistency will be unstable.

---

## Master Prompt

Use this block in every shot prompt.

```text
Use the reference product as the only source of truth.

Keep the product exactly the same:
same silhouette, same proportions, same color, same material, same texture, same logo position, same structural details.

Do not redesign, simplify, deform, stylize, replace, duplicate, or reinterpret the product.

Only change the camera angle, lighting, background, atmosphere, and composition.

Realistic commercial product photography, accurate industrial design, stable geometry, premium material rendering, clean composition.

Negative:
redesigned product, wrong shape, changed proportions, distorted logo, wrong logo position, missing details, extra parts, unstable geometry, melted product, duplicated product, incorrect material, inconsistent color, fake label, cartoon, cheap CGI, messy background.
```

---

## Chinese Master Prompt

```text
以参考产品为唯一标准。

产品必须完全一致：
相同轮廓、相同比例、相同颜色、相同材质、相同纹理、相同LOGO位置、相同结构细节。

不得重新设计、简化、变形、风格化、替换、复制或重新诠释产品。

只能改变镜头角度、光影、背景、氛围和构图。

真实商业产品摄影，准确工业设计，结构稳定，高级材质渲染，画面干净。

反向：
产品被重新设计，形状错误，比例变化，LOGO变形，LOGO位置错误，细节缺失，多余部件，结构不稳定，产品融化，产品重复，材质错误，颜色不一致，假标签，卡通，廉价CG，背景杂乱。
```

---

## Workflow

```text
Reference Lock
↓
White Background Product Test
↓
Multi-angle Consistency Test
↓
Simple Scene Test
↓
Final Shot Generation
↓
Shot-by-shot Reference Comparison
↓
Logo / Text / UI Post Fix
↓
Final Color and Material Match
```

Chinese version:

```text
参考图锁定
↓
产品白底测试
↓
多角度一致性测试
↓
简单场景测试
↓
正式分镜生成
↓
逐镜对比参考图
↓
Logo / 文字 / UI 后期修正
↓
统一调色与材质
```

---

## Loop

Use this loop for every generated frame or shot.

```text
Generate
↓
Compare with reference
↓
Find one main error
↓
Fix only that error
↓
Regenerate
↓
Approve or reject
```

Correction prompt:

```text
Only fix the product [problem].
Keep everything else unchanged.
```

Examples:

```text
Only fix the product proportions.
Keep everything else unchanged.
```

```text
Only fix the logo position.
Keep everything else unchanged.
```

```text
Only fix the material texture.
Keep everything else unchanged.
```

---

## Review Standard

Check only these 8 items:

1. Is the silhouette consistent?
2. Are the proportions consistent?
3. Is the color consistent?
4. Is the material consistent?
5. Is the logo position correct?
6. Are the structural details correct?
7. Is there any deformation, melting, duplication, or instability?
8. Does it look like a real commercial product, not a concept redesign?

---

## Pass Standard

Pass only when:

```text
Looks like the same product.
Accurate structure.
Stable proportions.
Correct logo.
Real material.
Ready for the next step.
```

---

## Fail Standard

Reject when:

```text
Product is redesigned.
Proportions changed obviously.
Logo is wrong.
Structure is wrong.
Material is wrong.
It does not look like the same product.
```

---

## Production Rule

For real commercial projects:

```text
AI generates environment, lighting, atmosphere, and cinematic camera feeling.
Real product images, 3D models, and post-production compositing protect product accuracy.
```

One-line rule:

```text
Lock the product first, then create the image.
Test consistency first, then create creative shots.
```
